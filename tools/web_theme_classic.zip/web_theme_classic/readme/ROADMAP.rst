* For the time being, the module improves form and search view. Some other improvement could
  be done on other part of the UI.
